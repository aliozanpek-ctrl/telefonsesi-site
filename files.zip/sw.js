// Bildirimlerin telefonda gosterilmesi icin gerekli (Android Chrome)
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((liste) => {
      if (liste.length) return liste[0].focus();
      return self.clients.openWindow("./");
    })
  );
});
